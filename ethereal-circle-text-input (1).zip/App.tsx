
import React, { useState, useEffect, useCallback, useRef } from 'react';
import { Modal } from './components/Modal';
import { CodeModal } from './components/CodeModal';
import { NoteModal } from './components/NoteModal';
import { TycoonModal } from './components/TycoonModal';

interface Projectile {
  id: number;
  startX: number;
  startY: number;
  targetX: number;
  targetY: number;
  isMoving: boolean;
  isExploding: boolean;
}

interface Command {
  type: 'move' | 'attack';
  value: number;
}

interface LogicNode {
  id: string;
  key: string;
  commands: Command[];
  subTriggers: LogicNode[];
  parent?: LogicNode;
}

interface Monster {
  id: number;
  x: number;
  y: number;
  hp: number;
  maxHp: number;
  lastHit: number;
}

const App: React.FC = () => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isCodeModalOpen, setIsCodeModalOpen] = useState(false);
  const [isNoteModalOpen, setIsNoteModalOpen] = useState(false);
  const [isTycoonModalOpen, setIsTycoonModalOpen] = useState(false);
  const [submittedText, setSubmittedText] = useState<string>("");
  
  // State for rendering
  const [renderPos, setRenderPos] = useState({ x: window.innerWidth / 2, y: window.innerHeight / 2 });
  const [angle, setAngle] = useState(0);
  const [projectiles, setProjectiles] = useState<Projectile[]>([]);
  const [monsters, setMonsters] = useState<Monster[]>([]);
  const [coins, setCoins] = useState(0); 
  const [points, setPoints] = useState(10); 
  const [showFlash, setShowFlash] = useState(false); 
  
  // Tycoon Stats
  const [attackLevel, setAttackLevel] = useState(0);
  const [productionLevel, setProductionLevel] = useState(0);
  const [explosionLevel, setExplosionLevel] = useState(0);
  
  // Tycoon Logic Values
  const attackPower = 20 * Math.pow(1.1, attackLevel); 
  const attackCost = 40 * Math.pow(1.3, attackLevel); 
  
  const maxMonsters = Math.floor(5 * Math.pow(1.5, productionLevel)); 
  const productionCost = 20 * Math.pow(1.5, productionLevel);

  const explosionRadius = 90 * Math.pow(1.1, explosionLevel); // 10%씩 지수적 증가
  const explosionCost = 30 * Math.pow(1.4, explosionLevel); // 비용 40%씩 지수적 증가

  // Status UI State
  const [activeLogicPath, setActiveLogicPath] = useState<LogicNode[]>([]);
  const [availableTriggers, setAvailableTriggers] = useState<LogicNode[]>([]);

  // Refs for loop
  const pressedKeysRef = useRef<Set<string>>(new Set());
  const posRef = useRef({ x: window.innerWidth / 2, y: window.innerHeight / 2 });
  const angleRef = useRef(0);
  const rootNodesRef = useRef<LogicNode[]>([]);
  const lastFiredActionsRef = useRef<Set<string>>(new Set());
  const pointsRef = useRef(10);
  const maxMonstersRef = useRef(5);

  useEffect(() => {
    maxMonstersRef.current = maxMonsters;
  }, [maxMonsters]);

  const nextProjectileId = useRef(0);
  const nextMonsterId = useRef(0);

  // 포인트 자동 회복
  useEffect(() => {
    const timer = setInterval(() => {
      if (pointsRef.current < 10) {
        const next = pointsRef.current + 1;
        pointsRef.current = next;
        setPoints(next);
      }
    }, 400);
    return () => clearInterval(timer);
  }, []);

  const spawnMonster = useCallback(() => {
    setMonsters(prev => {
      if (prev.length >= maxMonstersRef.current) return prev; 
      const margin = 100;
      const minPlayerDist = 200;
      let x = 0, y = 0, attempts = 0;
      while(attempts < 30) {
        x = margin + Math.random() * (window.innerWidth - margin * 2);
        y = margin + Math.random() * (window.innerHeight - margin * 2);
        const dist = Math.sqrt(Math.pow(x - posRef.current.x, 2) + Math.pow(y - posRef.current.y, 2));
        if (dist > minPlayerDist) break;
        attempts++;
      }
      return [...prev, { id: nextMonsterId.current++, x, y, hp: 100, maxHp: 100, lastHit: 0 }];
    });
  }, []);

  useEffect(() => {
    for (let i = 0; i < maxMonstersRef.current; i++) spawnMonster();
  }, [spawnMonster]);

  // Game Loop
  useEffect(() => {
    let animationFrameId: number;
    const MOVE_SPEED = 6;

    const loop = () => {
      if (isModalOpen || isNoteModalOpen || isTycoonModalOpen) {
        animationFrameId = requestAnimationFrame(loop);
        return;
      }

      const findActiveNodes = (nodes: LogicNode[], parentActive: boolean): LogicNode[] => {
        const active: LogicNode[] = [];
        for (const node of nodes) {
          if (pressedKeysRef.current.has(node.key) && parentActive) {
            active.push(node);
            active.push(...findActiveNodes(node.subTriggers, true));
            if (!node.parent) break; 
          }
        }
        return active;
      };

      const activeNodes = findActiveNodes(rootNodesRef.current, true);
      const currentActiveIds = new Set(activeNodes.map(n => n.id));
      setActiveLogicPath(activeNodes);
      
      if (activeNodes.length > 0) {
        setAvailableTriggers(activeNodes[activeNodes.length - 1].subTriggers);
      } else {
        setAvailableTriggers(rootNodesRef.current);
      }

      activeNodes.forEach(node => {
        node.commands.forEach(cmd => {
          if (cmd.type === 'move') {
            const rad = (cmd.value * Math.PI) / 180;
            angleRef.current = cmd.value;
            posRef.current.x = Math.max(50, Math.min(window.innerWidth - 50, posRef.current.x + Math.cos(rad) * MOVE_SPEED));
            posRef.current.y = Math.max(50, Math.min(window.innerHeight - 50, posRef.current.y + Math.sin(rad) * MOVE_SPEED));
          } else if (cmd.type === 'attack') {
            if (!lastFiredActionsRef.current.has(node.id + '-attack')) {
              if (cmd.value >= 100) {
                if (pointsRef.current > 0) {
                  const nextPoints = pointsRef.current - 1;
                  pointsRef.current = nextPoints;
                  setPoints(nextPoints);
                  const rad = (angleRef.current * Math.PI) / 180;
                  const tx = posRef.current.x + Math.cos(rad) * cmd.value;
                  const ty = posRef.current.y + Math.sin(rad) * cmd.value;
                  const id = nextProjectileId.current++;
                  setProjectiles(prev => [...prev, { id, startX: posRef.current.x, startY: posRef.current.y, targetX: tx, targetY: ty, isMoving: false, isExploding: false }]);
                  requestAnimationFrame(() => setProjectiles(prev => prev.map(p => p.id === id ? { ...p, isMoving: true } : p)));
                  setTimeout(() => {
                    setProjectiles(prev => prev.map(p => p.id === id ? { ...p, isExploding: true } : p));
                    applyDamage(tx, ty);
                    setTimeout(() => setProjectiles(prev => prev.filter(p => p.id !== id)), 500);
                  }, 400);
                } else {
                  setShowFlash(true);
                  setTimeout(() => setShowFlash(false), 150);
                }
              }
              lastFiredActionsRef.current.add(node.id + '-attack');
            }
          }
        });
      });

      lastFiredActionsRef.current.forEach(actionId => {
        const nodeId = actionId.split('-attack')[0];
        if (!currentActiveIds.has(nodeId)) lastFiredActionsRef.current.delete(actionId);
      });

      setRenderPos({ ...posRef.current });
      setAngle(angleRef.current);
      animationFrameId = requestAnimationFrame(loop);
    };

    animationFrameId = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(animationFrameId);
  }, [isModalOpen, isNoteModalOpen, isTycoonModalOpen]);

  const applyDamage = (tx: number, ty: number) => {
    const radius = explosionRadius; 
    const now = Date.now();
    setMonsters(prev => {
      const updated = prev.map(m => {
        const d = Math.sqrt((m.x - tx)**2 + (m.y - ty)**2);
        if (d < radius) {
          // 거리 기반 데미지 감쇄 로직: (1 - 거리/반지름) 비율로 데미지 적용
          const falloff = 1 - (d / radius);
          const finalDamage = attackPower * falloff;
          return { ...m, hp: Math.max(0, m.hp - finalDamage), lastHit: now };
        }
        return m;
      });
      const killed = updated.filter(m => m.hp <= 0).length;
      if (killed > 0) setCoins(c => c + killed * 5);
      return updated.filter(m => m.hp > 0);
    });
  };

  const handleUpgradeAttack = () => {
    if (coins >= attackCost) {
      setCoins(c => c - attackCost);
      setAttackLevel(l => l + 1);
    }
  };

  const handleUpgradeProduction = () => {
    if (coins >= productionCost) {
      setCoins(c => c - productionCost);
      setProductionLevel(l => l + 1);
    }
  };

  const handleUpgradeExplosion = () => {
    if (coins >= explosionCost) {
      setCoins(c => c - explosionCost);
      setExplosionLevel(l => l + 1);
    }
  };

  const handleAddCoins = (amount: number) => {
    setCoins(c => c + amount);
  };

  const parseLogic = (text: string): LogicNode[] => {
    const lines = text.split('\n');
    const root: LogicNode[] = [];
    const stack: { node: LogicNode; indent: number }[] = [];
    lines.forEach((line, idx) => {
      const indent = line.search(/\S/);
      if (indent === -1) return;
      const trimmed = line.trim();
      const keyMatch = trimmed.match(/input\s*key\s*\((.*?)\)\s*:?/i);
      if (keyMatch) {
        const key = keyMatch[1].trim().toLowerCase();
        const newNode: LogicNode = { id: `node-${idx}-${key}`, key, commands: [], subTriggers: [] };
        while (stack.length > 0 && stack[stack.length - 1].indent >= indent) stack.pop();
        if (stack.length === 0) root.push(newNode);
        else {
          const parent = stack[stack.length - 1].node;
          newNode.parent = parent;
          parent.subTriggers.push(newNode);
        }
        stack.push({ node: newNode, indent });
      } else {
        if (stack.length === 0) return;
        const currentNode = stack[stack.length - 1].node;
        const moveMatch = trimmed.match(/move\s*\((.*?)\)/i);
        if (moveMatch) currentNode.commands.push({ type: 'move', value: parseFloat(moveMatch[1]) || 0 });
        const attackMatch = trimmed.match(/attack1\s*\((.*?)\)/i);
        if (attackMatch) currentNode.commands.push({ type: 'attack', value: parseFloat(attackMatch[1]) || 200 });
      }
    });
    return root;
  };

  const handleModalSubmit = (text: string) => {
    setSubmittedText(text);
    rootNodesRef.current = parseLogic(text);
    lastFiredActionsRef.current.clear();
  };

  useEffect(() => {
    const down = (e: KeyboardEvent) => { if(!e.repeat) pressedKeysRef.current.add(e.key.toLowerCase()); };
    const up = (e: KeyboardEvent) => pressedKeysRef.current.delete(e.key.toLowerCase());
    window.addEventListener('keydown', down);
    window.addEventListener('keyup', up);
    return () => { window.removeEventListener('keydown', down); window.removeEventListener('keyup', up); };
  }, []);

  return (
    <div className="relative min-h-screen w-full bg-black overflow-hidden select-none">
      <div className={`fixed inset-0 z-[100] bg-red-600 pointer-events-none transition-opacity duration-300 ${showFlash ? 'opacity-40' : 'opacity-0'}`} />

      {/* HUD */}
      <div className="fixed top-6 left-6 z-40 flex flex-col gap-4">
        <div className="flex flex-col gap-1">
          <p className="text-[10px] text-zinc-600 uppercase tracking-widest font-black">Reserve</p>
          <div className="flex items-center gap-3">
            <div className="w-3 h-3 rounded-full bg-yellow-400 shadow-[0_0_15px_yellow]" />
            <span className="text-white text-xl font-bold tracking-tighter">{Math.floor(coins)} <span className="text-zinc-500 text-xs">COINS</span></span>
          </div>
        </div>
        
        <div className="flex flex-col gap-1">
          <p className="text-[10px] text-zinc-600 uppercase tracking-widest font-black">Energy</p>
          <div className="flex items-center gap-3">
            <div className="w-3 h-3 rounded-full bg-blue-500 shadow-[0_0_15px_rgba(59,130,246,0.8)]" />
            <div className="flex items-end gap-1">
              <span className={`text-xl font-bold tracking-tighter transition-colors ${points === 0 ? 'text-red-500 animate-pulse' : 'text-white'}`}>{points}</span>
              <span className="text-zinc-500 text-xs mb-1">/ 10</span>
            </div>
          </div>
          <div className="w-24 h-1 bg-zinc-900 rounded-full mt-1 overflow-hidden">
             <div className={`h-full transition-all duration-300 ${points === 0 ? 'bg-red-500' : 'bg-blue-500'}`} style={{ width: `${(points / 10) * 100}%` }} />
          </div>
        </div>
      </div>

      <div className="fixed top-8 left-1/2 -translate-x-1/2 z-40">
        <p className="text-white text-2xl font-black tracking-[0.2em]">{monsters.length} <span className="text-zinc-700">/ {maxMonsters}</span></p>
      </div>

      <div className="fixed top-6 right-6 z-40">
        <button onClick={() => setIsCodeModalOpen(true)} className="text-zinc-500 hover:text-white text-[10px] uppercase tracking-widest border border-zinc-800 px-4 py-2 rounded-full transition-colors">Dictionary</button>
      </div>

      {/* Control Buttons Bottom Left */}
      <div className="fixed bottom-6 left-6 z-40">
        <button 
          onClick={() => { if(coins >= 2 && monsters.length < maxMonsters) { setCoins(c => c - 2); spawnMonster(); } }}
          disabled={coins < 2 || monsters.length >= maxMonsters}
          className={`bg-zinc-950 border border-zinc-800 p-4 rounded-2xl flex items-center gap-4 transition-all ${ (coins < 2 || monsters.length >= maxMonsters) ? 'opacity-20 cursor-not-allowed' : 'hover:border-blue-500 hover:scale-105 active:scale-95'}`}
        >
          <div className="w-5 h-5 bg-blue-500 shadow-[0_0_10px_rgba(59,130,246,0.5)]" style={{ clipPath: 'polygon(50% 0%, 0% 100%, 100% 100%)' }} />
          <div className="text-left">
            <p className="text-white text-xs font-bold uppercase tracking-tight">Summon</p>
            <p className="text-yellow-400 text-[9px] font-black tracking-widest">-2 COIN</p>
          </div>
        </button>
      </div>

      <div className="fixed bottom-6 right-6 z-40 flex flex-col gap-3">
        <button onClick={() => setIsTycoonModalOpen(true)} className="w-14 h-14 bg-zinc-950 border border-zinc-800 rounded-2xl flex items-center justify-center hover:border-yellow-400 hover:scale-105 active:scale-95 transition-all group">
          <div className="flex flex-col items-center">
            <div className="w-4 h-1 bg-yellow-400 mb-1 rounded-full group-hover:shadow-[0_0_10px_yellow]" />
            <p className="text-[8px] text-zinc-500 font-black uppercase tracking-tighter group-hover:text-white">Tycoon</p>
          </div>
        </button>
        <button onClick={() => setIsNoteModalOpen(true)} className="w-14 h-14 bg-zinc-950 border border-zinc-800 rounded-2xl flex items-center justify-center hover:border-blue-500 hover:scale-105 active:scale-95 transition-all group">
          <div className="flex flex-col items-center">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-zinc-500 group-hover:text-blue-400 mb-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
            </svg>
            <p className="text-[8px] text-zinc-500 font-black uppercase tracking-tighter group-hover:text-white">Note</p>
          </div>
        </button>
      </div>

      {/* Monsters */}
      {monsters.map(m => (
        <div key={m.id} style={{ left: m.x, top: m.y }} className={`absolute z-10 -translate-x-1/2 -translate-y-1/2 transition-all duration-75 ${Date.now() - m.lastHit < 100 ? 'scale-125 brightness-150' : ''}`}>
          <div className="absolute -top-5 left-1/2 -translate-x-1/2 w-8 h-1 bg-zinc-900 rounded-full border border-zinc-800 overflow-hidden shadow-lg">
            <div className="h-full bg-blue-500 transition-all duration-300" style={{ width: `${(m.hp / m.maxHp) * 100}%` }} />
          </div>
          <div className="w-9 h-9 bg-blue-600 shadow-[0_0_30px_rgba(37,99,235,0.7)] border border-blue-400" style={{ clipPath: 'polygon(50% 0%, 0% 100%, 100% 100%)' }} />
        </div>
      ))}

      {/* Player */}
      <div 
        style={{ left: renderPos.x, top: renderPos.y, transform: `translate(-50%, -50%) rotate(${angle}deg)`, transition: 'transform 0.1s ease-out' }}
        className="absolute z-20 cursor-pointer"
        onClick={() => setIsModalOpen(true)}
      >
        <div className="w-12 h-12 rounded-full bg-white flex items-center justify-center shadow-[0_0_50px_rgba(255,255,255,0.4)] hover:scale-105 transition-transform">
          <div className="absolute -right-2 w-3.5 h-3.5 bg-yellow-400 rounded-full border-2 border-black shadow-[0_0_10px_yellow]" />
          <div className="w-1.5 h-1.5 bg-black rounded-full" />
        </div>
      </div>

      {/* Projectiles */}
      {projectiles.map(p => (
        <div key={p.id} style={{ left: p.isMoving ? p.targetX : p.startX, top: p.isMoving ? p.targetY : p.startY, transition: p.isExploding ? 'none' : 'all 0.4s cubic-bezier(0.1, 0.7, 0.1, 1)' }} className="absolute z-10 -translate-x-1/2 -translate-y-1/2">
          {p.isExploding ? (
            <div className="relative flex items-center justify-center">
              {/* 폭발 시각 효과: 업그레이드된 반지름(explosionRadius)에 맞게 동적 크기 조절 */}
              <div 
                className="absolute bg-white/20 rounded-full animate-ping" 
                style={{ width: explosionRadius * 2, height: explosionRadius * 2 }}
              />
              <div 
                className="absolute bg-yellow-400/40 rounded-full animate-pulse" 
                style={{ width: explosionRadius * 1.6, height: explosionRadius * 1.6 }}
              />
              <div className="w-4 h-4 bg-white rounded-full blur-[2px]" />
            </div>
          ) : (
            <div className="w-7 h-7 bg-yellow-400 shadow-[0_0_20px_yellow] animate-spin" style={{ clipPath: 'polygon(50% 0%, 61% 35%, 98% 35%, 68% 57%, 79% 91%, 50% 70%, 21% 91%, 32% 57%, 2% 35%, 39% 35%)', animationDuration: '0.2s' }} />
          )}
        </div>
      ))}

      <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} onSubmit={handleModalSubmit} initialValue={submittedText} title="Chord Logic Engine" />
      <CodeModal isOpen={isCodeModalOpen} onClose={() => setIsCodeModalOpen(false)} />
      <NoteModal isOpen={isNoteModalOpen} onClose={() => setIsNoteModalOpen(false)} currentCode={submittedText} onLoadCode={handleModalSubmit} />
      <TycoonModal 
        isOpen={isTycoonModalOpen} 
        onClose={() => setIsTycoonModalOpen(false)} 
        coins={coins}
        onUpgradeAttack={handleUpgradeAttack}
        onUpgradeProduction={handleUpgradeProduction}
        onUpgradeExplosion={handleUpgradeExplosion}
        onAddCoins={handleAddCoins}
        attackLevel={attackLevel}
        productionLevel={productionLevel}
        explosionLevel={explosionLevel}
        attackCost={attackCost}
        productionCost={productionCost}
        explosionCost={explosionCost}
        attackPower={attackPower}
        maxMonsters={maxMonsters}
        explosionRadius={explosionRadius}
      />
    </div>
  );
};

export default App;
