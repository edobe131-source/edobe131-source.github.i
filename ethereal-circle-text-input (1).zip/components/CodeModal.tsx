
import React, { useState } from 'react';

interface CodeModalProps {
  isOpen: boolean;
  onClose: () => void;
}

interface CodeItem {
  id: string;
  code: string;
  description: string;
}

export const CodeModal: React.FC<CodeModalProps> = ({ isOpen, onClose }) => {
  const [activeTab, setActiveTab] = useState<string>('all');

  if (!isOpen) return null;

  const tabs = [
    { id: 'all', label: 'ALL', locked: false },
    { id: '1', label: '1', locked: false },
    { id: '2', label: '2', locked: true },
    { id: '3', label: '3', locked: true },
  ];

  const module1Content: CodeItem[] = [
    { id: 'm1-1', code: 'input key():', description: '설정한 키를 누를때 발동합니다' },
    { id: 'm1-2', code: 'move()', description: '설정한 각도로 바라보고 이동합니다' },
    { id: 'm1-3', code: 'attack1(dist)', description: '바라보는 방향으로 공격합니다 (최소 사거리 100 이상 필요)' },
  ];

  const handleTabClick = (id: string, locked: boolean) => {
    if (!locked) {
      setActiveTab(id);
    }
  };

  const renderContent = () => {
    let items: CodeItem[] = [];
    if (activeTab === 'all' || activeTab === '1') {
      items = [...module1Content];
    }

    if (items.length === 0) {
      return (
        <div className="h-48 rounded-xl bg-zinc-900/30 border border-dashed border-zinc-800 flex flex-col items-center justify-center gap-2">
          <p className="text-zinc-600 text-[10px] uppercase tracking-widest italic">Encrypted Module</p>
        </div>
      );
    }

    return (
      <div className="space-y-6 max-h-[400px] overflow-y-auto pr-2 custom-scrollbar">
        {items.map((item) => (
          <div key={item.id} className="group border-l border-zinc-800 pl-4 py-1 hover:border-yellow-400 transition-colors">
            <code className="text-yellow-400/90 text-sm font-mono block mb-1 group-hover:text-yellow-400 transition-colors">
              {item.code}
            </code>
            <p className="text-zinc-400 text-xs font-light tracking-wide leading-relaxed">
              {item.description}
            </p>
          </div>
        ))}
      </div>
    );
  };

  return (
    <div 
      className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm transition-opacity duration-500"
      onClick={onClose}
    >
      <style>{`
        .custom-scrollbar::-webkit-scrollbar { width: 4px; }
        .custom-scrollbar::-webkit-scrollbar-track { background: transparent; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: #27272a; border-radius: 10px; }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover { background: #3f3f46; }
      `}</style>
      
      <div 
        className="bg-zinc-950 border border-zinc-800 w-full max-w-md rounded-2xl shadow-2xl overflow-hidden transform transition-all duration-300"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="p-6">
          <div className="flex items-center justify-between mb-8">
            <h3 className="text-xs font-bold text-zinc-500 uppercase tracking-widest">Code Access</h3>
            <button onClick={onClose} className="text-zinc-600 hover:text-white transition-colors">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>

          <div className="flex gap-2 mb-8">
            {tabs.map((tab) => {
              const isActive = activeTab === tab.id;
              
              return (
                <button
                  key={tab.id}
                  disabled={tab.locked}
                  onClick={() => handleTabClick(tab.id, tab.locked)}
                  className={`flex-1 py-2 rounded-lg text-xs font-bold transition-all duration-300 flex items-center justify-center gap-1
                    ${tab.locked 
                      ? 'bg-zinc-900 text-zinc-700 cursor-not-allowed border border-transparent' 
                      : isActive
                        ? 'bg-yellow-400 text-black shadow-[0_0_15px_rgba(250,204,21,0.4)] border border-yellow-300'
                        : 'bg-zinc-800 text-zinc-400 border border-zinc-700 hover:border-zinc-500'
                    }`}
                >
                  {tab.label}
                  {tab.locked && (
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M5 9V7a5 5 0 0110 0v2a2 2 0 012 2v5a2 2 0 01-2 2H5a2 2 0 01-2-2v-5a2 2 0 012-2zm8-2v2H7V7a3 3 0 016 0z" clipRule="evenodd" />
                    </svg>
                  )}
                </button>
              );
            })}
          </div>

          <div className="mb-4">
             <p className="text-zinc-500 text-[10px] uppercase tracking-widest mb-4 flex items-center gap-2">
                <span className={`w-1.5 h-1.5 rounded-full ${activeTab !== 'all' ? 'bg-yellow-400' : 'bg-blue-500'} animate-pulse`} />
                {activeTab === 'all' ? 'System Overview' : `Module ${activeTab} Sequence`}
             </p>
             {renderContent()}
          </div>
        </div>
      </div>
    </div>
  );
};
