
import React, { useEffect, useRef } from 'react';

interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (text: string) => void;
  title?: string;
  initialValue?: string;
}

export const Modal: React.FC<ModalProps> = ({ isOpen, onClose, onSubmit, title = "Input Text", initialValue = "" }) => {
  const [inputValue, setInputValue] = React.useState(initialValue);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // Update internal state when initialValue changes or modal opens
  useEffect(() => {
    if (isOpen) {
      setInputValue(initialValue);
      setTimeout(() => {
        if (textareaRef.current) {
          textareaRef.current.focus();
        }
      }, 50);
    }
  }, [isOpen, initialValue]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(inputValue);
    onClose();
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    // Submit on Cmd/Ctrl + Enter
    if ((e.metaKey || e.ctrlKey) && e.key === 'Enter') {
      handleSubmit(e);
    }
  };

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md transition-opacity duration-500"
      onClick={onClose}
    >
      <div 
        className="bg-zinc-950 border border-zinc-800 w-full max-w-lg rounded-3xl shadow-[0_0_100px_rgba(0,0,0,0.5)] overflow-hidden transform transition-all duration-500 scale-100"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="p-8">
          <h3 className="text-sm font-medium text-zinc-500 uppercase tracking-widest mb-6">{title}</h3>
          <form onSubmit={handleSubmit} className="space-y-6">
            <textarea
              ref={textareaRef}
              rows={8}
              value={inputValue}
              onKeyDown={handleKeyDown}
              onChange={(e) => setInputValue(e.target.value)}
              placeholder={`input key(f):\n  move(90)\n  attack1(200)`}
              className="w-full bg-transparent border-b border-zinc-800 text-white text-sm font-mono leading-relaxed resize-none focus:outline-none focus:border-white transition-colors placeholder:text-zinc-800 pb-4"
            />
            <div className="flex items-center justify-between">
              <span className="text-[10px] text-zinc-600 uppercase tracking-tighter">
                Press <kbd className="bg-zinc-900 px-1 rounded border border-zinc-800">⌘</kbd> + <kbd className="bg-zinc-900 px-1 rounded border border-zinc-800">Enter</kbd> to save
              </span>
              <div className="flex space-x-6">
                <button
                  type="button"
                  onClick={onClose}
                  className="text-zinc-500 hover:text-white transition-colors text-xs uppercase tracking-widest"
                >
                  Close
                </button>
                <button
                  type="submit"
                  className="text-white hover:text-zinc-300 transition-colors text-xs uppercase tracking-widest font-bold"
                >
                  Save Code
                </button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};
