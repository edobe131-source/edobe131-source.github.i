
import React, { useState } from 'react';

interface TycoonModalProps {
  isOpen: boolean;
  onClose: () => void;
  coins: number;
  onUpgradeAttack: () => void;
  onUpgradeProduction: () => void;
  onUpgradeExplosion: () => void;
  onAddCoins: (amount: number) => void;
  attackLevel: number;
  productionLevel: number;
  explosionLevel: number;
  attackCost: number;
  productionCost: number;
  explosionCost: number;
  attackPower: number;
  maxMonsters: number;
  explosionRadius: number;
}

export const TycoonModal: React.FC<TycoonModalProps> = ({
  isOpen,
  onClose,
  coins,
  onUpgradeAttack,
  onUpgradeProduction,
  onUpgradeExplosion,
  onAddCoins,
  attackLevel,
  productionLevel,
  explosionLevel,
  attackCost,
  productionCost,
  explosionCost,
  attackPower,
  maxMonsters,
  explosionRadius
}) => {
  const [activeTab, setActiveTab] = useState('1');
  const [devCode, setDevCode] = useState('');
  const [isDevUnlocked, setIsDevUnlocked] = useState(false);

  if (!isOpen) return null;

  const SECRET_CODE = "UxpR02idGh";

  const tabs = [
    { id: '1', label: 'TECH 1', locked: false },
    { id: '2', label: 'TECH 2', locked: true },
    { id: '3', label: 'TECH 3', locked: true },
    { id: 'dev', label: 'DEV', locked: false },
  ];

  const handleDevUnlock = () => {
    if (devCode === SECRET_CODE) {
      setIsDevUnlocked(true);
    } else {
      alert("Invalid Access Key");
    }
  };

  return (
    <div 
      className="fixed inset-0 z-[70] flex items-center justify-center p-4 bg-black/90 backdrop-blur-2xl transition-all duration-500"
      onClick={onClose}
    >
      <div 
        className="bg-zinc-950 border border-zinc-800 w-full max-w-3xl rounded-3xl shadow-2xl overflow-hidden flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-8 border-b border-zinc-900 flex items-center justify-between">
          <div>
            <h3 className="text-[10px] font-black text-yellow-500 uppercase tracking-[0.4em] mb-1">Corporate Expansion</h3>
            <p className="text-white text-2xl font-black tracking-tighter">TYCOON HUB</p>
          </div>
          <div className="text-right">
            <p className="text-[10px] text-zinc-500 uppercase font-bold tracking-widest">Available Capital</p>
            <p className="text-yellow-400 text-xl font-black">{Math.floor(coins)} <span className="text-[10px] text-zinc-600">COINS</span></p>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex px-8 py-4 gap-4 bg-zinc-900/20">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              disabled={tab.locked}
              onClick={() => setActiveTab(tab.id)}
              className={`flex-1 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all border ${
                tab.locked 
                  ? 'bg-zinc-950 border-zinc-900 text-zinc-800 cursor-not-allowed' 
                  : activeTab === tab.id
                    ? activeTab === 'dev' 
                      ? 'bg-zinc-100 border-zinc-200 text-black shadow-[0_0_20px_rgba(255,255,255,0.1)]'
                      : 'bg-yellow-400 border-yellow-300 text-black shadow-[0_0_20px_rgba(250,204,21,0.3)]'
                    : 'bg-zinc-900 border-zinc-800 text-zinc-500 hover:border-zinc-600'
              }`}
            >
              {tab.label} {tab.locked && "🔒"}
            </button>
          ))}
        </div>

        {/* Content */}
        <div className="p-8 space-y-4 max-h-[450px] overflow-y-auto custom-scrollbar">
          {activeTab === '1' ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {/* Attack Power Upgrade */}
              <div className="bg-zinc-900/40 border border-zinc-800 p-6 rounded-2xl flex flex-col justify-between hover:border-zinc-700 transition-colors group">
                <div>
                  <div className="flex justify-between items-start mb-4">
                    <div className="w-10 h-10 bg-red-500/10 rounded-lg flex items-center justify-center border border-red-500/20 group-hover:border-red-500/50 transition-colors">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-red-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                      </svg>
                    </div>
                    <span className="text-[10px] text-zinc-600 font-mono">LV. {attackLevel}</span>
                  </div>
                  <h4 className="text-white font-bold mb-1">Neural Overclock</h4>
                  <p className="text-[10px] text-zinc-500 uppercase tracking-tight leading-relaxed mb-6">
                    Increases damage by <span className="text-red-400">10%</span>.<br/>
                    Output: <span className="text-white">{attackPower.toFixed(1)} DMG</span>
                  </p>
                </div>
                <button 
                  onClick={onUpgradeAttack}
                  disabled={coins < attackCost}
                  className={`w-full py-3 rounded-xl font-black text-[10px] uppercase tracking-widest transition-all ${
                    coins >= attackCost 
                    ? 'bg-white text-black hover:bg-red-400' 
                    : 'bg-zinc-800 text-zinc-600 cursor-not-allowed'
                  }`}
                >
                  {Math.floor(attackCost)} C
                </button>
              </div>

              {/* Max Monster Production Upgrade */}
              <div className="bg-zinc-900/40 border border-zinc-800 p-6 rounded-2xl flex flex-col justify-between hover:border-zinc-700 transition-colors group">
                <div>
                  <div className="flex justify-between items-start mb-4">
                    <div className="w-10 h-10 bg-blue-500/10 rounded-lg flex items-center justify-center border border-blue-500/20 group-hover:border-blue-500/50 transition-colors">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-blue-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                      </svg>
                    </div>
                    <span className="text-[10px] text-zinc-600 font-mono">LV. {productionLevel}</span>
                  </div>
                  <h4 className="text-white font-bold mb-1">Mass Spawning</h4>
                  <p className="text-[10px] text-zinc-500 uppercase tracking-tight leading-relaxed mb-6">
                    Increases spawn limit <span className="text-blue-400">1.5x</span>.<br/>
                    Limit: <span className="text-white">{maxMonsters} UNIT</span>
                  </p>
                </div>
                <button 
                  onClick={onUpgradeProduction}
                  disabled={coins < productionCost}
                  className={`w-full py-3 rounded-xl font-black text-[10px] uppercase tracking-widest transition-all ${
                    coins >= productionCost 
                    ? 'bg-white text-black hover:bg-blue-400' 
                    : 'bg-zinc-800 text-zinc-600 cursor-not-allowed'
                  }`}
                >
                  {Math.floor(productionCost)} C
                </button>
              </div>

              {/* Explosion Radius Upgrade */}
              <div className="bg-zinc-900/40 border border-zinc-800 p-6 rounded-2xl flex flex-col justify-between hover:border-zinc-700 transition-colors group">
                <div>
                  <div className="flex justify-between items-start mb-4">
                    <div className="w-10 h-10 bg-yellow-500/10 rounded-lg flex items-center justify-center border border-yellow-500/20 group-hover:border-yellow-500/50 transition-colors">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-yellow-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9l9 7-9 7V9z" />
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 5L5 9v6l8 4V5z" />
                      </svg>
                    </div>
                    <span className="text-[10px] text-zinc-600 font-mono">LV. {explosionLevel}</span>
                  </div>
                  <h4 className="text-white font-bold mb-1">Shockwave Blast</h4>
                  <p className="text-[10px] text-zinc-500 uppercase tracking-tight leading-relaxed mb-6">
                    Increases blast area by <span className="text-yellow-400">10%</span>.<br/>
                    Range: <span className="text-white">{explosionRadius.toFixed(1)} px</span>
                  </p>
                </div>
                <button 
                  onClick={onUpgradeExplosion}
                  disabled={coins < explosionCost}
                  className={`w-full py-3 rounded-xl font-black text-[10px] uppercase tracking-widest transition-all ${
                    coins >= explosionCost 
                    ? 'bg-white text-black hover:bg-yellow-400' 
                    : 'bg-zinc-800 text-zinc-600 cursor-not-allowed'
                  }`}
                >
                  {Math.floor(explosionCost)} C
                </button>
              </div>
            </div>
          ) : activeTab === 'dev' ? (
            <div className="flex flex-col items-center justify-center h-full gap-6 min-h-[250px]">
              {!isDevUnlocked ? (
                <div className="w-full max-w-xs space-y-4 animate-in slide-in-from-bottom-4 duration-500">
                  <div className="text-center">
                    <p className="text-[10px] text-zinc-500 uppercase font-black tracking-[0.3em] mb-2">Administrator Authorization</p>
                    <div className="h-px bg-zinc-800 w-full mb-4" />
                  </div>
                  <input 
                    type="password"
                    placeholder="Enter Secret Key"
                    className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-4 py-3 text-xs text-center text-white outline-none focus:border-zinc-600 transition-colors"
                    value={devCode}
                    onChange={(e) => setDevCode(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleDevUnlock()}
                  />
                  <button 
                    onClick={handleDevUnlock}
                    className="w-full bg-zinc-100 text-black py-3 rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-white transition-all shadow-xl"
                  >
                    Authorize Access
                  </button>
                </div>
              ) : (
                <div className="w-full animate-in fade-in zoom-in duration-500">
                  <p className="text-[10px] text-zinc-500 uppercase font-black tracking-[0.3em] text-center mb-6">Internal Resource Control</p>
                  <div className="grid grid-cols-2 gap-4">
                    <button 
                      onClick={() => onAddCoins(100)}
                      className="bg-zinc-900 border border-zinc-800 p-4 rounded-xl text-[10px] font-black uppercase tracking-widest text-zinc-400 hover:text-white hover:border-zinc-600 transition-all"
                    >
                      GRANT 100 C
                    </button>
                    <button 
                      onClick={() => onAddCoins(1000)}
                      className="bg-zinc-900 border border-zinc-800 p-4 rounded-xl text-[10px] font-black uppercase tracking-widest text-yellow-500 hover:text-yellow-400 hover:border-yellow-900 transition-all shadow-inner"
                    >
                      GRANT 1000 C
                    </button>
                    <button 
                      onClick={() => onAddCoins(10000)}
                      className="col-span-2 bg-zinc-100 text-black p-4 rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-white transition-all"
                    >
                      GRANT 10000 C
                    </button>
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div className="h-64 flex items-center justify-center border border-dashed border-zinc-800 rounded-3xl">
              <p className="text-zinc-700 text-[10px] uppercase tracking-[0.5em] font-black italic">Module Encrypted</p>
            </div>
          )}
        </div>

        <div className="p-8 bg-zinc-950 flex justify-center">
           <button onClick={onClose} className="text-[10px] text-zinc-600 hover:text-white uppercase font-black tracking-widest transition-colors">Close Interface</button>
        </div>
      </div>
      <style>{`
        .custom-scrollbar::-webkit-scrollbar { width: 4px; }
        .custom-scrollbar::-webkit-scrollbar-track { background: transparent; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: #18181b; border-radius: 10px; }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover { background: #27272a; }
      `}</style>
    </div>
  );
};
