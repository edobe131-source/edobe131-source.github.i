
import React, { useState, useEffect } from 'react';

interface Note {
  id: string;
  title: string;
  code: string;
  timestamp: number;
}

interface NoteModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentCode: string;
  onLoadCode: (code: string) => void;
}

export const NoteModal: React.FC<NoteModalProps> = ({ isOpen, onClose, currentCode, onLoadCode }) => {
  const [notes, setNotes] = useState<Note[]>([]);
  const [selectedNoteId, setSelectedNoteId] = useState<string | null>(null);
  const [editingCode, setEditingCode] = useState('');
  const [isNamingNew, setIsNamingNew] = useState(false);
  const [tempTitle, setTempTitle] = useState('');
  const [isRenaming, setIsRenaming] = useState(false);

  // 데이터 로드
  useEffect(() => {
    if (isOpen) {
      const saved = localStorage.getItem('chord-notes');
      if (saved) {
        const parsed = JSON.parse(saved);
        setNotes(parsed);
        if (parsed.length > 0 && !selectedNoteId) {
          const firstNote = parsed[0];
          setSelectedNoteId(firstNote.id);
          setEditingCode(firstNote.code);
        }
      }
    }
  }, [isOpen]);

  // 선택된 노트가 바뀔 때 편집기 내용 업데이트
  useEffect(() => {
    const note = notes.find(n => n.id === selectedNoteId);
    if (note) {
      setEditingCode(note.code);
      setIsRenaming(false);
    }
  }, [selectedNoteId, notes]);

  const saveToStorage = (updated: Note[]) => {
    setNotes(updated);
    localStorage.setItem('chord-notes', JSON.stringify(updated));
  };

  const handleCreateFile = () => {
    if (!tempTitle.trim()) return;
    const newNote: Note = {
      id: Date.now().toString(),
      title: tempTitle.trim(),
      code: currentCode || '# New Script\ninput key(f):\n  move(0)',
      timestamp: Date.now(),
    };
    const updated = [newNote, ...notes];
    saveToStorage(updated);
    setSelectedNoteId(newNote.id);
    setIsNamingNew(false);
    setTempTitle('');
  };

  const handleSaveChanges = () => {
    if (!selectedNoteId) return;
    const updated = notes.map(n => 
      n.id === selectedNoteId ? { ...n, code: editingCode, timestamp: Date.now() } : n
    );
    saveToStorage(updated);
    alert('파일 내용이 저장되었습니다.');
  };

  const handleRename = () => {
    if (!selectedNoteId || !tempTitle.trim()) return;
    const updated = notes.map(n => 
      n.id === selectedNoteId ? { ...n, title: tempTitle.trim(), timestamp: Date.now() } : n
    );
    saveToStorage(updated);
    setIsRenaming(false);
    setTempTitle('');
  };

  const handleImportFromEngine = () => {
    setEditingCode(currentCode);
  };

  const handleDelete = (id: string) => {
    const updated = notes.filter(n => n.id !== id);
    saveToStorage(updated);
    if (selectedNoteId === id) {
      if (updated.length > 0) {
        setSelectedNoteId(updated[0].id);
        setEditingCode(updated[0].code);
      } else {
        setSelectedNoteId(null);
        setEditingCode('');
      }
    }
  };

  const selectedNote = notes.find(n => n.id === selectedNoteId);

  if (!isOpen) return null;

  return (
    <div 
      className="fixed inset-0 z-[70] flex items-center justify-center p-4 bg-black/95 backdrop-blur-2xl transition-all duration-500"
      onClick={onClose}
    >
      <div 
        className="bg-zinc-950 border border-zinc-800 w-full max-w-5xl h-[80vh] rounded-3xl shadow-2xl overflow-hidden flex flex-row"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Sidebar: File Explorer */}
        <div className="w-64 border-r border-zinc-900 flex flex-col bg-zinc-950/50">
          <div className="p-6 border-b border-zinc-900 flex items-center justify-between">
            <h3 className="text-[10px] font-black text-zinc-500 uppercase tracking-[0.2em]">Explorer</h3>
            <button 
              onClick={() => setIsNamingNew(true)}
              className="text-zinc-400 hover:text-white transition-colors"
              title="New File"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
              </svg>
            </button>
          </div>

          <div className="flex-1 overflow-y-auto custom-scrollbar p-2 space-y-1">
            {isNamingNew && (
              <div className="p-2 animate-in fade-in slide-in-from-top-2 duration-300">
                <input 
                  autoFocus
                  className="w-full bg-zinc-900 border border-blue-500/50 rounded-lg px-3 py-2 text-xs text-white outline-none"
                  placeholder="Filename..."
                  value={tempTitle}
                  onChange={e => setTempTitle(e.target.value)}
                  onKeyDown={e => {
                    if (e.key === 'Enter') handleCreateFile();
                    if (e.key === 'Escape') setIsNamingNew(false);
                  }}
                />
              </div>
            )}

            {notes.map(note => (
              <button
                key={note.id}
                onClick={() => setSelectedNoteId(note.id)}
                className={`w-full text-left p-3 rounded-xl flex items-center gap-3 transition-all group ${selectedNoteId === note.id ? 'bg-zinc-900 text-white shadow-inner' : 'text-zinc-500 hover:bg-zinc-900/50 hover:text-zinc-300'}`}
              >
                <svg xmlns="http://www.w3.org/2000/svg" className={`h-4 w-4 ${selectedNoteId === note.id ? 'text-blue-400' : 'text-zinc-700'}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 21h10a2 2 0 002-2V9.414a1 1 0 00-.293-.707l-5.414-5.414A1 1 0 0012.586 3H7a2 2 0 00-2 2v14a2 2 0 002 2z" />
                </svg>
                <span className="text-xs font-medium truncate flex-1">{note.title}</span>
                {selectedNoteId === note.id && (
                  <div className="w-1.5 h-1.5 rounded-full bg-blue-500 animate-pulse" />
                )}
              </button>
            ))}

            {notes.length === 0 && !isNamingNew && (
              <div className="p-8 text-center">
                <p className="text-[10px] text-zinc-700 uppercase font-bold tracking-widest italic opacity-50">Storage Empty</p>
              </div>
            )}
          </div>
        </div>

        {/* Main Content: File Editor */}
        <div className="flex-1 flex flex-col bg-black/20">
          {selectedNote ? (
            <>
              <div className="p-8 border-b border-zinc-900 flex items-center justify-between">
                <div className="flex-1">
                  {isRenaming ? (
                    <input 
                      autoFocus
                      className="bg-transparent text-white text-xl font-black outline-none border-b border-blue-500"
                      value={tempTitle}
                      onChange={e => setTempTitle(e.target.value)}
                      onBlur={handleRename}
                      onKeyDown={e => { if(e.key === 'Enter') handleRename(); if(e.key === 'Escape') setIsRenaming(false); }}
                    />
                  ) : (
                    <h4 
                      className="text-white text-xl font-black tracking-tight flex items-center gap-3 cursor-pointer hover:text-blue-400 transition-colors"
                      onClick={() => { setIsRenaming(true); setTempTitle(selectedNote.title); }}
                      title="Click to rename"
                    >
                      {selectedNote.title}
                      <span className="text-[10px] bg-zinc-900 text-zinc-500 px-2 py-0.5 rounded uppercase tracking-widest font-bold">.chord</span>
                    </h4>
                  )}
                  <p className="text-[10px] text-zinc-600 font-mono mt-1">
                    Modified: {new Date(selectedNote.timestamp).toLocaleString()} • {editingCode.length} bytes
                  </p>
                </div>
                <div className="flex gap-2">
                   <button 
                    onClick={() => handleDelete(selectedNote.id)}
                    className="p-2 text-zinc-600 hover:text-red-500 hover:bg-red-500/10 rounded-xl transition-all"
                    title="Delete"
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                    </svg>
                  </button>
                  <div className="w-px h-8 bg-zinc-900 mx-2 self-center" />
                  <button 
                    onClick={handleImportFromEngine}
                    className="px-4 py-2 text-zinc-500 text-[10px] font-black uppercase tracking-widest hover:text-white transition-all"
                  >
                    Pull from Engine
                  </button>
                  <button 
                    onClick={handleSaveChanges}
                    className="px-5 py-2 border border-blue-500/30 text-blue-400 text-[10px] font-black uppercase tracking-widest rounded-xl hover:bg-blue-500 hover:text-white transition-all shadow-[0_0_15px_rgba(59,130,246,0.1)]"
                  >
                    Save File
                  </button>
                  <button 
                    onClick={() => { onLoadCode(editingCode); onClose(); }}
                    className="px-6 py-2 bg-white text-black text-[10px] font-black uppercase tracking-widest rounded-xl hover:bg-yellow-400 transition-all shadow-[0_0_20px_rgba(255,255,255,0.1)]"
                  >
                    Apply to Engine
                  </button>
                </div>
              </div>
              
              <div className="flex-1 p-8 overflow-hidden relative group">
                <textarea
                  className="w-full h-full bg-zinc-950/50 border border-zinc-900 rounded-2xl p-8 font-mono text-sm text-zinc-300 outline-none focus:border-zinc-700 transition-colors resize-none leading-relaxed custom-scrollbar"
                  spellCheck={false}
                  value={editingCode}
                  onChange={e => setEditingCode(e.target.value)}
                  placeholder="# Write your logic here..."
                />
                <div className="absolute top-12 right-12 text-[9px] text-zinc-800 font-mono pointer-events-none opacity-0 group-focus-within:opacity-100 transition-opacity uppercase tracking-widest">
                  Editing Mode
                </div>
              </div>
            </>
          ) : (
            <div className="flex-1 flex flex-col items-center justify-center text-zinc-800">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 mb-4 opacity-10" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
              </svg>
              <p className="text-xs uppercase tracking-[0.4em] font-black italic">Select or create a neural sequence</p>
            </div>
          )}
        </div>
      </div>
      
      <style>{`
        .custom-scrollbar::-webkit-scrollbar { width: 6px; }
        .custom-scrollbar::-webkit-scrollbar-track { background: transparent; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: #18181b; border-radius: 10px; }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover { background: #27272a; }
      `}</style>
    </div>
  );
};
